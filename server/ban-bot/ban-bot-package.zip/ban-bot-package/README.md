# ban-bot

Herramienta para bloquear bots por User-Agent (ej. SemrushBot, AhrefsBot)
a nivel de Traefik, en servidores con Coolify. El bloqueo es global:
aplica a todos los dominios/servicios detrás de ese Traefik.

A diferencia de `ban-ip` (que opera en iptables/capa de red), `ban-bot`
opera en la capa HTTP, inspeccionando el header User-Agent, porque
iptables no puede ver ese dato.

## Instalación

1. Copia esta carpeta completa a tu servidor.
2. Entra a la carpeta y ejecuta el instalador:

   ```bash
   cd ban-bot-package
   chmod +x install-ban-bot.sh
   sudo ./install-ban-bot.sh
   ```

El instalador:
- Verifica que exista /data/coolify/proxy/dynamic (indicio de que
  Coolify/Traefik están instalados).
- Verifica si el contenedor de Traefik está corriendo (aviso, no
  bloqueante).
- Copia `ban-bot` a /usr/local/bin/ban-bot.
- Prepara /etc/ban-bot/patterns.list para guardar los patrones
  bloqueados.

## Uso

```bash
sudo ban-bot --ban "SemrushBot"      # bloquea un user-agent
sudo ban-bot --list                  # lista los user-agents bloqueados
sudo ban-bot --delete "SemrushBot"   # elimina un bloqueo
```

## Cómo funciona

Cada vez que agregas o quitas un patrón, `ban-bot` regenera un archivo
YAML en:

```
/data/coolify/proxy/dynamic/ban-bot.yml
```

Ese archivo define un router de Traefik con prioridad alta que
intercepta cualquier request cuyo header `User-Agent` coincida (con
cualquiera de los patrones, case-insensitive) y lo responde con 403.
Traefik recarga su configuración dinámica automáticamente — no hace
falta reiniciar nada.

## Verificar que un bloqueo funciona

```bash
curl -A "Mozilla/5.0 (compatible; SemrushBot/7~bl)" -I https://tu-dominio.com/
```

Debería devolver `HTTP/2 403`. Si no es así, revisa los logs del
contenedor de Traefik:

```bash
docker logs coolify-proxy
```

y el contenido generado en:

```bash
cat /data/coolify/proxy/dynamic/ban-bot.yml
```

**Nota:** el mecanismo de bloqueo usa el middleware `errors` de Traefik
como forma de forzar un 403 sin plugins externos. No ha sido probado
en un Traefik en producción — verifica con el curl de arriba después
de cada --ban antes de confiar en que está bloqueando.
