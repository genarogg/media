#!/bin/bash
#
# install-ban-bot.sh — instalador de la herramienta ban-bot
#
# Qué hace:
#   1. Verifica que Coolify/Traefik estén presentes en este servidor
#      (carpeta /data/coolify/proxy/dynamic).
#   2. Copia el comando ban-bot a /usr/local/bin.
#   3. Prepara el directorio de patrones (/etc/ban-bot) — no requiere
#      systemd, porque el archivo de patrones y la config de Traefik
#      viven en disco en /data/coolify/..., que ya persiste por sí
#      solo entre reinicios (es la misma carpeta que usa Coolify).
#
# Uso:
#   sudo ./install-ban-bot.sh

set -euo pipefail

if [ -t 1 ]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; NC=''
fi

err() { echo -e "${RED}Error:${NC} $1" >&2; }
ok()  { echo -e "${GREEN}$1${NC}"; }
info(){ echo -e "${YELLOW}$1${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DYNAMIC_DIR="/data/coolify/proxy/dynamic"

if [ "$(id -u)" -ne 0 ]; then
  err "Este instalador debe ejecutarse como root. Usa: sudo ./install-ban-bot.sh"
  exit 1
fi

if [ ! -f "$SCRIPT_DIR/ban-bot" ]; then
  err "No se encontró el archivo 'ban-bot' en $SCRIPT_DIR."
  err "Asegúrate de tener 'install-ban-bot.sh' y 'ban-bot' en la misma carpeta."
  exit 1
fi

echo "=== Instalador de ban-bot ==="
echo ""

# --- 1. Verifica que Coolify/Traefik estén presentes ---
if [ ! -d "$DYNAMIC_DIR" ]; then
  err "No se encontró $DYNAMIC_DIR."
  err "ban-bot depende de Coolify + Traefik para funcionar (bloqueo por User-Agent"
  err "a nivel de proxy HTTP). Verifica que Coolify esté instalado y corriendo."
  exit 1
fi
ok "✓ Carpeta de configuración dinámica de Traefik encontrada ($DYNAMIC_DIR)."

# Verifica que el contenedor de Traefik esté corriendo (si docker está disponible)
if command -v docker >/dev/null 2>&1; then
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -qi traefik; then
    ok "✓ Contenedor de Traefik detectado en ejecución."
  else
    info "No se detectó un contenedor de Traefik corriendo. ban-bot instalará igual,"
    info "pero el bloqueo no tendrá efecto hasta que Traefik esté activo."
  fi
fi

# --- 2. Instala el comando ---
echo ""
info "Instalando comando 'ban-bot' en /usr/local/bin..."
install -m 0755 "$SCRIPT_DIR/ban-bot" /usr/local/bin/ban-bot
ok "✓ ban-bot instalado. Ya puedes usarlo como: sudo ban-bot --list"

# --- 3. Prepara el directorio de patrones ---
mkdir -p /etc/ban-bot
touch /etc/ban-bot/patterns.list
ok "✓ Directorio de patrones listo en /etc/ban-bot/patterns.list"

# --- 4. Resumen final ---
echo ""
ok "=== Instalación completa ==="
echo ""
echo "Comandos disponibles:"
echo "  sudo ban-bot --ban \"SemrushBot\""
echo "  sudo ban-bot --list"
echo "  sudo ban-bot --delete \"SemrushBot\""
echo ""
echo "El bloqueo aplica globalmente a todos los dominios/servicios detrás"
echo "de Traefik en esta instancia de Coolify, y persiste tras reinicios"
echo "porque vive en ${DYNAMIC_DIR}, la misma carpeta que gestiona Coolify."
