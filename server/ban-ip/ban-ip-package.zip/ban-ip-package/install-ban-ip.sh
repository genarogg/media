#!/bin/bash
#
# install-ban-ip.sh — instalador de la herramienta ban-ip
#
# Qué hace:
#   1. Verifica si ipset, iptables e iptables-persistent están instalados.
#      Si falta alguno, pregunta antes de instalarlo.
#   2. Copia el comando ban-ip a /usr/local/bin para que quede disponible
#      globalmente.
#   3. Crea un servicio systemd (ban-ip-restore) que recarga el ipset
#      'blocklist' y la regla en DOCKER-USER en cada arranque del
#      servidor, para que los bloqueos sobrevivan a reinicios.
#
# Uso:
#   sudo ./install-ban-ip.sh
#
# Debe ejecutarse desde la misma carpeta donde está el archivo "ban-ip".

set -euo pipefail

# --- Colores ---
if [ -t 1 ]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; NC=''
fi

err() { echo -e "${RED}Error:${NC} $1" >&2; }
ok()  { echo -e "${GREEN}$1${NC}"; }
info(){ echo -e "${YELLOW}$1${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SET_NAME="blocklist"
IPTABLES_RULE_CHAIN="DOCKER-USER"
IPSET_SAVE_FILE="/etc/ipset/${SET_NAME}.conf"
SYSTEMD_SERVICE_PATH="/etc/systemd/system/ban-ip-restore.service"

# --- 1. Verifica que se ejecute como root ---
if [ "$(id -u)" -ne 0 ]; then
  err "Este instalador debe ejecutarse como root. Usa: sudo ./install-ban-ip.sh"
  exit 1
fi

# --- 2. Verifica que exista el archivo ban-ip junto al instalador ---
if [ ! -f "$SCRIPT_DIR/ban-ip" ]; then
  err "No se encontró el archivo 'ban-ip' en $SCRIPT_DIR."
  err "Asegúrate de tener 'install-ban-ip.sh' y 'ban-ip' en la misma carpeta."
  exit 1
fi

echo "=== Instalador de ban-ip ==="
echo ""

# --- 3. Detecta el gestor de paquetes ---
if command -v apt-get >/dev/null 2>&1; then
  PKG_INSTALL="apt-get install -y"
  PKG_UPDATE="apt-get update"
elif command -v dnf >/dev/null 2>&1; then
  PKG_INSTALL="dnf install -y"
  PKG_UPDATE="dnf check-update || true"
elif command -v yum >/dev/null 2>&1; then
  PKG_INSTALL="yum install -y"
  PKG_UPDATE="yum check-update || true"
else
  err "No se detectó un gestor de paquetes compatible (apt, dnf, yum)."
  exit 1
fi

UPDATED_PKG_INDEX=0
ensure_pkg_index_updated() {
  if [ "$UPDATED_PKG_INDEX" -eq 0 ]; then
    info "Actualizando índice de paquetes..."
    eval "$PKG_UPDATE" >/dev/null 2>&1 || true
    UPDATED_PKG_INDEX=1
  fi
}

# --- 4. Verifica cada dependencia y pregunta antes de instalar ---
# pkg_name -> comando a verificar (algunos paquetes no exponen un binario
# con el mismo nombre, p.ej. iptables-persistent)
declare -A DEPS=(
  ["ipset"]="ipset"
  ["iptables"]="iptables"
)

for pkg in "${!DEPS[@]}"; do
  bin="${DEPS[$pkg]}"
  if command -v "$bin" >/dev/null 2>&1; then
    ok "✓ $pkg ya está instalado."
  else
    echo ""
    read -r -p "El paquete '$pkg' no está instalado. ¿Deseas instalarlo ahora? [S/n] " resp
    resp="${resp:-S}"
    if [[ "$resp" =~ ^[Ss]$ ]]; then
      ensure_pkg_index_updated
      info "Instalando $pkg..."
      eval "$PKG_INSTALL $pkg"
      ok "✓ $pkg instalado."
    else
      err "No se puede continuar sin '$pkg'. Abortando instalación."
      exit 1
    fi
  fi
done

# iptables-persistent es especial: en Debian/Ubuntu pide confirmación
# interactiva para guardar reglas IPv4/IPv6 durante la instalación.
if dpkg -s iptables-persistent >/dev/null 2>&1 2>/dev/null || [ -f /etc/iptables/rules.v4 ]; then
  ok "✓ iptables-persistent ya está instalado."
elif command -v apt-get >/dev/null 2>&1; then
  echo ""
  read -r -p "El paquete 'iptables-persistent' no está instalado (recomendado para persistencia extra). ¿Deseas instalarlo ahora? [S/n] " resp
  resp="${resp:-S}"
  if [[ "$resp" =~ ^[Ss]$ ]]; then
    ensure_pkg_index_updated
    info "Instalando iptables-persistent..."
    # Evita el prompt interactivo de guardado de reglas durante la instalación
    echo iptables-persistent iptables-persistent/autosave_v4 boolean true | debconf-set-selections
    echo iptables-persistent iptables-persistent/autosave_v6 boolean true | debconf-set-selections
    eval "$PKG_INSTALL iptables-persistent"
    ok "✓ iptables-persistent instalado."
  else
    info "Continuando sin iptables-persistent. La persistencia se manejará igual vía systemd (ver más abajo)."
  fi
else
  info "iptables-persistent no aplica a este gestor de paquetes; la persistencia se maneja vía systemd."
fi

# --- 5. Instala el comando ban-ip ---
echo ""
info "Instalando comando 'ban-ip' en /usr/local/bin..."
install -m 0755 "$SCRIPT_DIR/ban-ip" /usr/local/bin/ban-ip
ok "✓ ban-ip instalado. Ya puedes usarlo como: sudo ban-ip --list"

# --- 6. Crea el ipset y la regla de iptables ahora mismo (estado inicial) ---
echo ""
info "Preparando ipset '$SET_NAME' y regla en $IPTABLES_RULE_CHAIN..."
if ! ipset list -n | grep -qx "$SET_NAME"; then
  ipset create "$SET_NAME" hash:ip
fi
if ! iptables -C "$IPTABLES_RULE_CHAIN" -m set --match-set "$SET_NAME" src -j DROP 2>/dev/null; then
  iptables -I "$IPTABLES_RULE_CHAIN" -m set --match-set "$SET_NAME" src -j DROP
fi
mkdir -p /etc/ipset
ipset save "$SET_NAME" > "$IPSET_SAVE_FILE"
ok "✓ Set y regla listos."

# --- 7. Crea el servicio systemd que restaura todo en cada arranque ---
echo ""
info "Configurando persistencia vía systemd (ban-ip-restore.service)..."

cat > "$SYSTEMD_SERVICE_PATH" <<EOF
[Unit]
Description=Restaura el ipset de ban-ip y la regla en ${IPTABLES_RULE_CHAIN} al arrancar
After=network-pre.target docker.service
Before=network.target
Wants=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c '\
  mkdir -p /etc/ipset; \
  if [ -f ${IPSET_SAVE_FILE} ]; then \
    ipset restore -exist < ${IPSET_SAVE_FILE}; \
  else \
    ipset create -exist ${SET_NAME} hash:ip; \
  fi; \
  iptables -C ${IPTABLES_RULE_CHAIN} -m set --match-set ${SET_NAME} src -j DROP 2>/dev/null \
    || iptables -I ${IPTABLES_RULE_CHAIN} -m set --match-set ${SET_NAME} src -j DROP \
'

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ban-ip-restore.service >/dev/null 2>&1
ok "✓ Servicio ban-ip-restore habilitado. Se ejecutará en cada reinicio."

# --- 8. Resumen final ---
echo ""
ok "=== Instalación completa ==="
echo ""
echo "Comandos disponibles:"
echo "  sudo ban-ip --list"
echo "  sudo ban-ip --ban IP"
echo "  sudo ban-ip --delete IP"
echo ""
echo "La lista de IPs bloqueadas se guarda en: $IPSET_SAVE_FILE"
echo "y se restaura automáticamente en cada arranque mediante el servicio"
echo "'ban-ip-restore.service' (systemctl status ban-ip-restore)."
