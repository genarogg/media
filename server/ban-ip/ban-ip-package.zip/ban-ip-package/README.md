# ban-ip

Herramienta para bloquear IPs en un servidor con Docker/Coolify, usando
ipset + iptables (cadena DOCKER-USER), con persistencia ante reinicios
vía systemd.

## Instalación

1. Copia esta carpeta completa a tu servidor (por ejemplo con scp o
   descomprimiendo el zip).
2. Entra a la carpeta y ejecuta el instalador:

   ```bash
   cd ban-ip-package
   chmod +x install-ban-ip.sh
   sudo ./install-ban-ip.sh
   ```

El instalador:
- Verifica si ipset, iptables e iptables-persistent están instalados y
  pregunta antes de instalar cualquiera que falte.
- Copia `ban-ip` a /usr/local/bin/ban-ip (queda disponible como comando
  global).
- Crea y habilita el servicio systemd `ban-ip-restore.service`, que
  restaura el ipset y la regla de iptables en cada arranque del
  servidor.

## Uso

```bash
sudo ban-ip --ban IP       # bloquea una IP
sudo ban-ip --list         # lista las IPs bloqueadas
sudo ban-ip --delete IP    # elimina un bloqueo
```

## Verificar persistencia

```bash
sudo systemctl status ban-ip-restore
```
